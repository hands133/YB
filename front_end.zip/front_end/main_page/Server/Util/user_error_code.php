<?php
/**
 * Created by PhpStorm.
 * User: 23670
 * Date: 2019/3/23
 * Time: 19:04
 */
// 定义状态常量
const SUCCESS = 1;
const INTERNET_ERROR = -1;
const ACCOUNT_NOT_EXISTED_ERROR = -2;
const WRONG_PASSWORD_ERROR = -3;
const SELECT_ERROR = -4;
const INSERT_ERROR = -5;
const ACTIVE_NODE_ERROR = -6;